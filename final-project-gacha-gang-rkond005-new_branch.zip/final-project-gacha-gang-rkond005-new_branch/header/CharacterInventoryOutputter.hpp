#ifndef CHARACTERINVENTORYOUTPUTTER_HPP
#define CHARACTERINVENTORYOUTPUTTER_HPP
#include "CharacterInventory.hpp"
#include "Character.hpp"
#include <iostream>
#include <vector>

using namespace std;

class CharacterInventoryOutputter {
    
    public:
        void displayCharacterInfo(Character* individual);
        void displayCharacterList(vector<Character*> list);
        
    
};


#endif