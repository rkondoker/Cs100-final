#ifndef CHARACTERINVENTORYMENUOUTPUTTER_HPP
#define CHARACTERINVENTORYMENUOUTPUTTER_HPP

#include "../header/CharacterInventory.hpp"
#include "../header/Character.hpp"
#include <iostream>

using namespace std;

class CharacterInventoryMenuOutputter {
    public:
        void displayMainCharacterInventoryMenu( CharacterInventory* characters);
        void moveFromMainCharacterInventoryMenu( CharacterInventory* characters);
        void displayEditListMenu( CharacterInventory* characters);
        void moveFromEditListMenu(  CharacterInventory* characters);


};

#endif