#ifndef ELEMENT_HPP
#define ELEMENT_HPP

#include <iostream>

using namespace std;

class Element {
    private: 
        string name;
        string strength;
        string weakness;

    public: 
        Element();
        Element(string names, string strengths, string weaknesses);
        //Returns the name of the element
        string getElementName();
        //Returns what element this element is strong against
        string getStrength();
        //Returns what element this element is weak against
        string getWeakness();
};

#endif 