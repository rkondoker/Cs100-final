#ifndef CHARACTER_HPP
#define CHARACTER_HPP

#include "CharacterOutputter.hpp"
//#include "CurrencyManager.h"
#include "Element.hpp"
//#include "Equipment.h"
//#include "Level.h"
//#include "Skill.h"
#include <cmath>
#include <iostream>

using namespace std;

class Character {
private:
  string name;
  Element elementalType;
  int rarity;
  int health;
  int attack;
  int defense;  
  CharacterOutputter* characterOutput;

public:
  Character();
  Character(string characterName, Element elements, int rarities);
  string getName();
  Element getElement();
  int getRarity();
  //Level getLevel();
  //Skill getSkill();
  //Equipment getEquipment();
  int getHealth();
  int getAttack();
  int getDefense();
  void healthCalc();
  void attackCalc();
  void defenseCalc();
  //void removeEquipment();
  //void addEquipment(Equipment equipment);
  //void feed(int foods, CurrencyManager *Currencies);
  CharacterOutputter* getCharacterOutput();
};

#endif