#ifndef CHARACTEROUTPUTTER_HPP
#define CHARACTEROUTPUTTER_HPP

#include <iostream>
#include "Element.hpp"
//#include "Level.h"
//#include "Skill.h"
//#include "Equipment.h"

using namespace std;

class CharacterOutputter {

    public: 
        //Display the element
        void displayElement(Element elementType);
        //Displays the rarity
        void displaysRarity(int rarity);
        //Displays the equipment the character uses
        //void displayEquipment(Equipment equip);
        //Displays the base health of the character
        void displayHealth(int health);
        //Displays the base attack of the character
        void displayAttack(int attack);
        //Displays the base defense of the character
        void displayDefense(int defense); 
        //Displays a more simplified profile that contains some of the information on the character
        void displaySimplifiedCharacterProfile(string characterName, Element elementType, int rarity);
        //Displays a profile with all of the information on the skill
        void displayCharacterProfile(string characterName, Element elementType, int rarity,  int health, int attack, int defense); 
        
};

#endif 