#ifndef SUMMONOUTPUTTER_HPP
#define SUMMONOUTPUTTER_HPP

#include <iostream>
#include <cmath>
#include "Summon.hpp"

class Summon;

class SummonOutputter{

    private:
    Summon *summoner;

    public:
    void displaySummons();
    void displayRates();
    void displayTotals();
};

#endif 
