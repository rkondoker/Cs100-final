#ifndef INVENTORYMANAGER_HPP
#define INVENTORYMANAGER_HPP

#include <iostream>
#include "Character.hpp"
#include "CharacterInventory.hpp"
#include "CharacterInventoryMenuOutputter.hpp"
#include <vector>

using namespace std;

class InventoryManager{
    private:
        CharacterInventory* characterList;
        CharacterInventoryMenuOutputter* charInventoryMenu;


    public:
        InventoryManager();
        CharacterInventory* getCharacterInventory();
        CharacterInventoryMenuOutputter* getCharacterInventoryMenu();
        


};

#endif 