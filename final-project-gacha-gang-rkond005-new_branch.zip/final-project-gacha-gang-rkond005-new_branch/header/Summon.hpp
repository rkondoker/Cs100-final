#ifndef SUMMON_HPP
#define SUMMON_HPP

#include <iostream>
#include <cmath>
#include "Element.hpp"
//#include "Skill.h"
#include "SummonOutputter.hpp"
#include "Character.hpp"


using namespace std;

class Summon {

private:
SummonOutputter summonOutput;
int totalSummons;
int totalFire;
int totalWater;
int totalEarth;
int totalLight;
int totalDark;
int totalOne;
int totalTwo;
int totalThree;
int totalFour;
int totalFive;


public:
Summon();
int generateRarityOneToThree();
int generateRarityThreeToFive();
Element generateElement();
//Skill generateSkill();
Character oneToThreeSummon();
Character threeToFiveSummon();
Character tenPlusOneOneToThreeSummon();
Character tenPlusOneThreeToFiveSummon();
void addToTotal();
int getTotalSummons();
int getTotalFire();
int getTotalWater();
int getTotalEarth();
int getTotalLight();
int getTotalDark();
int getTotalOne();
int getTotalTwo();
int getTotalThree();
int getTotalFour();
int getTotalFive();
SummonOutputter getSummonOutput();

};

#endif 