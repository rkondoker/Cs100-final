#ifndef CHARACTERINVENTORY_HPP
#define CHARACTERINVENTORY_HPP

#include <iostream>
#include "Character.hpp"
#include "CharacterInventoryOutputter.hpp"
#include <vector>

using namespace std;

class CharacterInventoryOutputter;


class CharacterInventory {
    private: 
        vector<Character*> characterMainList;
        int characterCapacity;
        int currCharacterNum;
        CharacterInventoryOutputter *listOut;

    public:
        CharacterInventory();
        CharacterInventory(int charCap, int currNum);
        int getCapacity();
        int getCurrNum();
        void addToCharacterInventory(Character* x);
        //void addCapacity(Currency* coins);
        vector<int> getCharacterList();
        vector<int> sortByTypeRarity();
        vector<int> sortByHealth();
        vector<int> sortByAttack();
        vector<int> sortByDefense();
        vector<int> filterType(string type);
        vector<int> filterRarity(int rarity);
        Character* accessCharacter(int index);
        CharacterInventoryOutputter getCharacterInventoryOut() const;
        int getNumberOfCharacters() const;
        vector<Character*> getCharacterVector() const;
        void removeCharacter(int index);
        

};

#endif 