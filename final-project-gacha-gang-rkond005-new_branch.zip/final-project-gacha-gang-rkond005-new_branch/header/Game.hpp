#ifndef GAME_HPP
#define GAME_HPP

#include <iostream>
#include <cmath>
#include "Summon.hpp"
#include "Character.hpp"
//#include "CurrencyManager.h"
#include "InventoryManager.hpp"
#include <iostream>
#include <cmath>


using namespace std;

class Game {


    private:
    
     //CurrencyManager currency;
     Summon theSummoner;
     InventoryManager* inventories;
     //BattleManager battles;
     //ShopManager shop;
     //MissionManager missions;

     public:
     Game();
     void displayMainMenu();
     void moveFromMainMenu();
     void displaySummonMenu();
     void moveFromSummonMenu();
     /*void displayInventoryMenu();
     void moveFromInventoryMenu();
     void displayBattleMenu();
     void moveFromBattleMenu();
     void displayShopMenu();
     void moveFromShopMenu();
     void displayMissionMenu();
     void moveFromMissionMenu();
*/
};

#endif