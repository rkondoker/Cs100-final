#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include<cmath>
#include <ctime> 
#include "../header/Summon.hpp"
#include "../header/SummonOutputter.hpp"

using namespace std;


void SummonOutputter :: displaySummons(/*CharacterOutputter characterOutput, Character characters*/){


cout << "Character's element is: ";
cout << "Character's level is: ";
cout << "Character's health is: ";
cout << "Character's atack is: ";
cout << "Character's defense is: ";
cout << "Character's equipment is: ";
cout << "Character's profile is: ";
}

void SummonOutputter:: displayRates(){

 cout << "The display rates for a one to three summon are the following:" << endl;
 cout << "These percentages have been rounded to the hundreths place." << endl;

 cout << "1-star = 51.95 %" << endl;
 cout << "2-star = 38.96 %" << endl;
 cout << "3-star = 9.1 %" << endl;  

 cout << "The display rates for a three to five summon are the following:" << endl;
 cout << "3-star = 56.67 %" << endl;
 cout << "4-star = 33.33 %" << endl;
 cout << "5-star = 10 %" << endl;


 }

void SummonOutputter:: displayTotals(){


 cout << "Total characters summoned: " << summoner->getTotalSummons() << endl;
 cout << "Total Fire characters summoned: " << summoner->getTotalFire() << endl;
 cout << "Total water characters summoned: " << summoner->getTotalWater() << endl;
 cout << "Total earth characters summoned: " << summoner->getTotalEarth() << endl;
 cout << "Total light characters summoned: " << summoner->getTotalLight() << endl;
 cout << "Total dark characters summoned: " << summoner->getTotalDark() << endl;
 cout << "Total 1-star characters summoned: " << summoner->getTotalOne() << endl;
 cout << "Total 2-star characters summoned: " << summoner->getTotalTwo() << endl;
 cout << "Total 3-star characters summoned: " << summoner->getTotalThree() << endl;
 cout << "Total 4-star characters summoned: " << summoner->getTotalFour() << endl;
 cout << "Total 5-star characters summoned: " << summoner->getTotalFive() << endl;

}
