#include "../header/Summon.hpp"
#include "../header/SummonOutputter.hpp"
#include <iostream>
using namespace std;

Summon::Summon(/*int totalSummons, int totalFire, int totalWater, int totalEarth, int totalLight, int totalDark
, int totalOne, int totalTwo, int totalThree, int totalFour, int totalFive*/){

    totalSummons = 0;

    totalFire = 0;

    totalWater = 0;

    totalEarth = 0;

    totalLight = 0;

    totalDark = 0;

    totalOne = 0;

    totalTwo = 0;

    totalThree = 0;

    totalFour = 0;

    totalFive = 0;





}


int Summon :: generateRarityOneToThree(){
    srand( time(0) );
  int summonRarityNum = ((rand()%77)+1);   // Generates a random number 1-77
  int rarity;
  
  switch(summonRarityNum){
    
    case 1 ... 40:
    rarity = 1;
    totalOne++;  
    break;

    
    case 41 ... 70:
    rarity = 2;
    totalTwo++;
    break;

    case 71 ... 77:
    rarity = 3;
    totalThree++;
    break;

    default:
    cout << "SummonRarityNum not a # between 1 & 77" << endl;
      
    break;
  }
  return rarity;
}

int Summon :: generateRarityThreeToFive(){
    srand( time(0) );
  int summonRarityNum = ((rand()%30)+1);   // Generates a random number 1-30
  int rarity;
  
  switch(summonRarityNum){
    case 1 ... 3:
    rarity = 5;
    totalFive++;    // Summoning rarirty counters
    break;

    case 4 ... 13:
    rarity = 4;
    totalFour++;
    break;
    
    case 14 ... 30:
    rarity = 3;
    totalThree++;
    break;

    default:
    cout << "SummonRarityNum not a # between 1 & 30" << endl;
    break;
  }

  return rarity;
}

Element Summon :: generateElement(){
  srand( time(0) );
  int summonElementNum = ((rand()%5)+1);    // Generates random number 1-5
  string element;
  string strength;
  string weakness;
  
  switch(summonElementNum){
    case 1:
    element = "Fire";
    strength = "Earth";    // Element class variables
    weakness = "Water";
    totalFire++;    // Summoning element counters
    break;

    case 2:
    element = "Water";
    strength = "Fire";    // Element class variables
    weakness = "Earth";
    totalWater++;    // Summoning element counters
    break;

    case 3:
    element = "Earth";
    strength = "Water";    // Element class variables
    weakness = "Fire";
    totalEarth++;    // Summoning element counters
    break;

    case 4:
    element = "Light";
    strength = "Dark";    // Element class variables
    weakness = "None";
    totalLight++;    // Summoning element counters
    break;

    case 5:
    element = "Dark";
    strength = "Light";    // Element class variables
    weakness = "None";
    totalDark++;    // Summoning element counters
    break;

    default:
    cout << "summonElementNumj not a # between 1 & 5" << endl;
    break;

  }

  Element a(element,strength,weakness);
  return a;
}

/*Skill Summon :: generateSkill(){

 srand( time(0) );
  int summonSkillNum = ((rand()%7)+1);    // Generates random number 1-7
  string skillName;
  string skillStat;
  string skillEffect;
  string characterEffected;
  double statAmountChange;
  int turn;
  int accuracy;

  switch(summonSkillNum){
    case 1:
    skillName = "Super atack";
    skillStat = "";
    skillEffect = "skillEff1";    
    characterEffected = "attacking the opposing team with an attack powered ";    // Skill class variables (need them from cathy so i can plug in)
    statAmountChange = 2;    //multiplier
    turn = 0;   // same as rarrity
    accuracy = 0;   //rarity*10 + 40
    break;

    case 2:
    skillName = "Shield";
    skillStat = "";
    skillEffect = "creating a shield for your team using team health by ";    
    characterEffected = "charEff2";    // Skill class variables (need them from cathy so i can plug in)
    statAmountChange = 0.2;
    turn = 0;
    accuracy = 0;
    break;

    case 3:
    skillName = "Heal";
    skillStat = "";
    skillEffect = "skillEff3";    
    characterEffected = "increasing your team using team heath by ";    // Skill class variables (need them from cathy so i can plug in)
    statAmountChange = 0.3;
    turn = 0;
    accuracy = 0;
    break;

    case 4:
    skillName = "Atack up";
    skillStat = "";
    skillEffect = "raising your team attack by ";    
    characterEffected = "charEff4";    // Skill class variables (need them from cathy so i can plug in)
    statAmountChange = 1.5;
    turn = 0;
    accuracy = 0;
    break;

    case 5:
    skillName = "Defense up";
    skillStat = "";
    skillEffect = "raising your team defense by ";    
    characterEffected = "charEff5";    // Skill class variables (need them from cathy so i can plug in)
    statAmountChange = 1.5;
    turn = 0;
    accuracy = 0;
    break;

    case 6:
    skillName = "Poison";
    skillStat = "";
    skillEffect = "decreasing opponent using team heath by ";    
    characterEffected = "charEff6";    // Skill class variables (need them from cathy so i can plug in)
    statAmountChange = 0.05;
    turn = 0;
    accuracy = 0;
    break;

    case 7:
    skillName = "Paralyze";
    skillStat = "";
    skillEffect = "immobilize team opponent team ";    
    characterEffected = "charEff7";    // Skill class variables (need them from cathy so i can plug in)
    statAmountChange = 0;
    turn = 0;
    accuracy = 0;
    break;

    default:
    cout << "summonSkillnum not a # between 1 & 7" << endl;
    break;

  }

  Skill a(skillName,skillStat,skillEffect,characterEffected,
  statAmountChange,turn,accuracy);
  
  return a;

}*/

Character Summon :: oneToThreeSummon(){
  string characterName;
  cout << "Please give your character a name: " << endl;
  cin >> characterName;
  Character aCharacter(characterName, generateElement(), generateRarityOneToThree());
  totalSummons++;
  return aCharacter;
}

Character Summon::threeToFiveSummon(){

string characterName;
cout << "Please give your character a name: " << endl;
cin >> characterName;
Character aCharacter(characterName, generateElement(), generateRarityThreeToFive()/*,generateSkill()*/);
totalSummons++;
  return aCharacter;
}

Character Summon :: tenPlusOneOneToThreeSummon(){

  for(int i = 0; i < 10; i++){
      string characterName;
  cout << "Please give your character a name: " << endl;
  cin >> characterName;
  Character aCharacter(characterName, generateElement(), generateRarityOneToThree());
  totalSummons++;
  return aCharacter;
    }
}

Character Summon :: tenPlusOneThreeToFiveSummon(){

  for(int i = 0; i < 10; i++){
       string characterName;
  cout << "Please give your character a name: " << endl;
  cin >> characterName;
  Character aCharacter(characterName, generateElement(), generateRarityThreeToFive());
  totalSummons++;
  return aCharacter;
    }
}


int Summon :: getTotalSummons(){
  return totalSummons;
}

int Summon :: getTotalFire(){
  return totalFire;
}

int Summon :: getTotalWater(){
  return totalWater;
}

int Summon :: getTotalEarth(){
  return totalEarth;
}

int Summon :: getTotalLight(){
  return totalLight;
}

int Summon :: getTotalDark(){
  return totalDark;
}

int Summon :: getTotalOne(){
  return totalOne;
}

int Summon :: getTotalTwo(){
  return totalTwo;
}

int Summon :: getTotalThree(){
  return totalThree;
}

int Summon :: getTotalFour(){
  return totalFour;
}

int Summon :: getTotalFive(){
  return totalFive;
}

SummonOutputter Summon :: getSummonOutput(){
  return summonOutput;
}