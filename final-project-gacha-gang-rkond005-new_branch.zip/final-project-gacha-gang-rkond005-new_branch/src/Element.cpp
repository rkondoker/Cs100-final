#include <iostream>
#include "../header/Element.hpp"

using namespace std;

Element::Element() {
    name = "";
    strength = "";
    weakness = "";
}

Element::Element(string names, string strengths, string weaknesses) {
    name = names;
    strength = strengths;
    weakness = weaknesses;
}

//Returns the name of the element
string Element::getElementName() {
    return name;
}

//Returns what element this element is strong against
string Element::getStrength() {
    return strength;
}

//Returns what element this element is weak against
string Element::getWeakness() {
    return weakness;
}