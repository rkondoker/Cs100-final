#include "../header/CharacterInventoryMenuOutputter.hpp"
#include "../header/CharacterInventory.hpp"
#include "../header/Character.hpp"
#include "../header/CharacterInventoryOutputter.hpp"
#include <vector>
#include <iostream>
using namespace std;

void CharacterInventoryMenuOutputter::displayMainCharacterInventoryMenu( CharacterInventory* characters){
    cout << "Character Inventory Main Menu" << endl;
    cout << "You have " << characters->getNumberOfCharacters() << " characters" << endl;
    cout << "Options: " << endl;
    cout << "1: View Characters (unsorted)" << endl;
    cout << "2: Edit Inventory" << endl;
    cout << "(Any): Return to main menu" << endl;
    moveFromMainCharacterInventoryMenu(characters);
}

void CharacterInventoryMenuOutputter::moveFromMainCharacterInventoryMenu( CharacterInventory* characters){
    int option = 0;
    cout << "Please select an option: ";
    cin >> option;
    switch(option) {
        case 1: 
            cout << "Your Characters: " << endl;
            characters->getCharacterInventoryOut().displayCharacterList(characters->getCharacterVector());
            cout << endl;
            
            break;

        case 2: 
            cout << "Going to Edit List Menu" << endl;
            displayEditListMenu(characters);
            break;
        default:
            cout << "Going back to main inventory menu\n" << endl;
            break; 
    }

}

void CharacterInventoryMenuOutputter::displayEditListMenu( CharacterInventory* characters){
    cout << "Edit List menu" << endl;
    cout << "1: remove character from list" << endl;
    cout << "(any) return to character inventory menu" << endl;
    moveFromEditListMenu(characters);
}

void CharacterInventoryMenuOutputter::moveFromEditListMenu( CharacterInventory* characters){
    int option = 0;
    cout << "Please select an option: ";
    cin >> option;
    switch(option) {
        case 1: 
            cout << "Enter index of character to be removed" << endl;
            int index;
            cin >> index;
            characters->removeCharacter(index);
            
            break;


        default:
            cout << "Going back to main inventory menu\n" << endl;
            displayMainCharacterInventoryMenu(characters);
            break; 
    }

}
