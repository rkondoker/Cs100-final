#include "../header/Game.hpp"
using namespace std;
#include <iostream>



Game :: Game(){
  theSummoner = Summon();
  inventories = new InventoryManager();
}



void Game :: displayMainMenu(){


cout << "what menu would you like to display? " << endl;
cout << "1. Summon Menu" << endl;
cout << "2. Inventory Menu" << endl;
//cout << "3. Battle Menu" << endl;
//cout << "4. Shop Menu" << endl;
//cout << "5. Mission Menu" << endl;
cout << "3. Exit game" << endl;
cout << "Enter the corresponding number" << endl;
moveFromMainMenu();
    
}


void Game :: moveFromMainMenu(){

int mainMenuChoice;
cin >> mainMenuChoice;
switch(mainMenuChoice){

    case 1:
    cout << "Here's the summon menu below" << endl;
    displaySummonMenu();
    break;

    case 2:
    cout << "Here's the inventory menu below" << endl;
    inventories->getCharacterInventoryMenu()->displayMainCharacterInventoryMenu(inventories->getCharacterInventory());
    displayMainMenu();
    break;

    /*/ case 3:
    cout << "Here's the battle menu below" << endl;
    displayBattleMenu();
    break;

    case 4:
    cout << "Here's the shop menu below" << endl;
    displayShopMenu();
    break;

    case 5:
    cout << "Here's the mission menu below" << endl;
    displayMissionMenu();
    break;*/

  case 3:
    cout << "Thank You For Playing!";
    break;

    default:
    cout << "Please enter a number 1-3" << endl;
    displayMainMenu();
    break;
}
  }

void Game :: displaySummonMenu(){
cout << "what would you like to do ? " << endl;
cout << "1. Summon once from the 1-3 star banner" << endl;
cout << "2. Summon once from the 3-5 star banner" << endl;
cout << "3. Summon 10x + 1 free summon from the 1-3 star banner" << endl;
cout << "4. Summon 10x + 1 free summon from the 3-5 star banner" << endl;
cout << "5. Display rates for the 1-3  & 3-5 star banner" << endl;
cout << "6. Display totals for characters summoned sorted by rarity & element" << endl;
cout << "7. Go back to main menu" << endl;
cout << "Enter the corresponding number" << endl;
moveFromSummonMenu();

}

void Game :: moveFromSummonMenu(){
int summonMenuChoice;
cin >> summonMenuChoice;

switch(summonMenuChoice){

    case 1:{
    cout << "You've chosen a single pull from the 1-3 star banner " << endl;
    cout << "Below is your summoned character: " << endl;
      // create character and assign name / generate element & rarity
      
      Character* newCharacter = new Character(theSummoner.oneToThreeSummon());
       //display character's attributes
    newCharacter->getCharacterOutput()->displayCharacterProfile(newCharacter->getName(), newCharacter->getElement(), newCharacter->getRarity(), newCharacter->getHealth(), newCharacter->getAttack(), newCharacter->getDefense());
      //push character into character inventory
      inventories->getCharacterInventory()->addToCharacterInventory(newCharacter);
      //inventories->getCharacterInventory()->addToCharacterInventory(newCharacter);
      cout << "Returning to main menu" << endl;
      //delete newCharacter;
      displayMainMenu();
      
      }
    break; 


    case 2:{
    cout << "You've chosen a single pull from the 3-5 star banner " << endl;
    cout << "Below is your summoned character: " << endl;
       // create character and assign name / generate element & rarity
Character* newCharacter = new Character(theSummoner.oneToThreeSummon());       
      //display character's attributes
    //newCharacter.getCharacterOutput().displayCharacterProfile(newCharacter.getName(), newCharacter.getElement(), newCharacter.getRarity(), newCharacter.getHealth(), newCharacter.getAttack(), newCharacter.getDefense());
      //push character into character inventory
      inventories->getCharacterInventory()->addToCharacterInventory(newCharacter);
      cout << endl << "adding to inv" << endl;
      delete newCharacter;
      displayMainMenu();
      }
    break;

    case 3: {
    cout << "You've chosen a 10x +1 free pull from the 1-3 star banner " << endl;
    cout << "Below are your summoned characters " << endl;
     for(int i = 0; i < 10; i++){
        // create character and assign name / generate element & rarity
Character* newCharacter = new Character(theSummoner.oneToThreeSummon());        
       //display character's attributes
    //newCharacter.getCharacterOutput().displayCharacterProfile(newCharacter.getName(), newCharacter.getElement(), newCharacter.getRarity(), newCharacter.getHealth(), newCharacter.getAttack(), newCharacter.getDefense());
         //push character into character inventory
       inventories->getCharacterInventory()->addToCharacterInventory(newCharacter);  
       delete newCharacter;
       }
       displayMainMenu();
      
      }
    break;

    case 4:{
    cout << "You've chosen a 10x +1 free pull from the 3-5 star banner " << endl;
    cout << "Below are your summoned characters " << endl;
      for(int i = 0; i < 10; i++){
         // create character and assign name / generate element & rarity
Character* newCharacter = new Character(theSummoner.oneToThreeSummon());
        //display character's attributes
    //newCharacter.getCharacterOutput().displayCharacterProfile(newCharacter.getName(), newCharacter.getElement(), newCharacter.getRarity(), newCharacter.getHealth(), newCharacter.getAttack(), newCharacter.getDefense());
         //push character into character inventory
         inventories->getCharacterInventory()->addToCharacterInventory(newCharacter);
        delete newCharacter;
        }
      }
    break;

    case 5:{
    cout << "You've chosen to display banner rates " << endl;
    Summon displayRatesObject;
    displayRatesObject.getSummonOutput().displayRates();
      }
    break;

    case 6:{
    cout << "You've chosen to display totals " << endl;
    Summon displayTotalsObject;
    displayTotalsObject.getSummonOutput().displayTotals();
      }
    break;

    case 7:{
    cout << "You've chosen to go back to the main menu " << endl;
    displayMainMenu();
      }
    break;

    default:{
    cout <<  "Please Choose a number between 1-7 " << endl;
    displaySummonMenu();
      }
    break;


}
  }