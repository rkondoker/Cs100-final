#include <iostream>
#include "../header/Element.hpp"
#include "../header/CharacterOutputter.hpp"

using namespace std; 

//Display the element
void CharacterOutputter::displayElement(Element elementType) {
    cout << "Element: " << elementType.getElementName() << endl;
}

//Displays the rarity
void CharacterOutputter::displaysRarity(int rarity) {
  cout << "Rarity: " << rarity << " Stars" << endl;
}



//Displays the base health of the character
void CharacterOutputter::displayHealth(int baseHealth) {
    cout << "Health: " << baseHealth << endl;
}

//Displays the base attack of the character
void CharacterOutputter::displayAttack(int baseAttack) {
    cout << "Attack: " << baseAttack << endl;
}
        
//Displays the base defense of the character
void CharacterOutputter::displayDefense(int baseDefense) {
    cout << "Defense: " << baseDefense << endl;
}

//Displays a more simplified profile that contains some of the information on the character
void CharacterOutputter::displaySimplifiedCharacterProfile(string characterName, Element elementType, int rarity) {
    cout << characterName << endl;
    displayElement(elementType); 
    displaysRarity(rarity);
  

}
        
//Displays a profile with all of the information on the skill
void CharacterOutputter::displayCharacterProfile(string characterName, Element elementType, int rarity, int health, int attack, int defense) {
    cout << characterName << endl; 
    displayElement(elementType); 
    cout << endl;
    displaysRarity(rarity);
    cout << "\n" << endl;
    displayHealth(health);
    cout << endl;
    displayAttack(attack);
    cout << endl;
    displayDefense(defense);
    cout << endl;
  
  
}