#include "../header/InventoryManager.hpp"
#include "../header/CharacterInventoryMenuOutputter.hpp"
#include <iostream>

using namespace std;

InventoryManager::InventoryManager(){
    characterList = new CharacterInventory();
}


CharacterInventory* InventoryManager::getCharacterInventory(){
    return this->characterList;
}

CharacterInventoryMenuOutputter* InventoryManager::getCharacterInventoryMenu(){
    return charInventoryMenu;
}
