#include "../header/CharacterInventory.hpp"
#include "../header/Character.hpp"
#include "../header/CharacterInventoryOutputter.hpp"
#include "../header/CharacterOutputter.hpp"
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

CharacterInventory::CharacterInventory(){
    Element fire = Element("Fire", "Earth", "Water");
    Element water = Element("Water", "Fire", "Earth");
    Element earth = Element("Earth", "Water", "Fire");
    Element light = Element("Light", "Dark", "");
    Element dark = Element("Dark", "Light", "");
    Character* oneStar = new Character("bob", fire, 1);
    Character* twoStar = new Character("Coral", water, 2);
    Character* threeStar = new Character("Ang", earth, 3);
    Character* fourStar = new Character("Sora", light, 4);
    Character* fiveStar = new Character("Drax", dark, 5);
    characterMainList.push_back(oneStar);
    characterMainList.push_back(twoStar);
    characterMainList.push_back(threeStar);
    characterMainList.push_back(fourStar);
    characterMainList.push_back(fiveStar);
    characterCapacity = 1000;
    currCharacterNum = 100;
}

CharacterInventory::CharacterInventory(int charCap, int currNum){
    characterCapacity = charCap;
    currCharacterNum = currNum;
}

int CharacterInventory::getCapacity(){
    return this -> characterCapacity;
}

int CharacterInventory::getCurrNum(){
    return currCharacterNum;
}

void CharacterInventory::addToCharacterInventory(Character* x){
    this->characterMainList.push_back(x); 
}

/*void CharacterInventory::addCapacity(Currency* coins){
    if(coins->getCurrencyAmount() >= 20000){
        coins->changeCurrencyAmount(-20000);
        this->characterCapacity++;
    }
    else{
        coins->getCurrencyOutput().displayChangeCurrencyNotEnoughError("coins");
    }
}*/

vector<int> CharacterInventory::getCharacterList(){
    vector<int> charIndexes;
    for(int i=0; i < this->characterMainList.size()-1; i++){
        charIndexes.push_back(i);
        i++;
    }
  return charIndexes;
}

vector<int> CharacterInventory::filterRarity(int rarity){
    vector<int> rarityVec;
    for(int i = 0; i <  this->characterMainList.size()-1; i++){
        if(this->characterMainList.at(i)->getRarity() == rarity){
            rarityVec.push_back(i);
        }
        i++;
    }
  return rarityVec;
}

vector<int> CharacterInventory::filterType(string type){
    vector<int> typeyVec;
    for(int i = 0; i <  this->characterMainList.size()-1; i++){
        if(this->characterMainList.at(i)->getElement().getElementName() == type){
            typeyVec.push_back(i);
        }
        i++;
    }
  return typeyVec;
} 

Character* CharacterInventory::accessCharacter(int index){
    return this->characterMainList.at(index);
}

/* bool CharacterInventory::compareAttack(const& Character lhs, const& character rhs){
    return lhs.getAttack() < rhs.getAttack();
}
vector<int> CharacterInventory::sortByAttack(){
    vector<int> charIndexes = getCharacterList();
    sort(charIndexes.begin(), charIndexes.end(), [&](int index1, int index2)){
        return compareAttack()
    }
    
}
*/

CharacterInventoryOutputter CharacterInventory::getCharacterInventoryOut() const {
    return *listOut;
}

int CharacterInventory::getNumberOfCharacters() const{
  return this->characterMainList.size();
}

vector<Character*> CharacterInventory::getCharacterVector() const {
  return characterMainList;
}

void CharacterInventory::removeCharacter(int index){
    characterMainList.erase(characterMainList.begin() + index - 1);
}