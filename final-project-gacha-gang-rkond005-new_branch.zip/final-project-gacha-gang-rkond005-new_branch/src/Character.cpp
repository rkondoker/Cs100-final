#include <iostream>
#include <cmath>
#include "../header/CharacterOutputter.hpp" 
#include "../header/Character.hpp"

using namespace std;

//default constructor
Character::Character() {
    name = "";
    elementalType = Element();
    rarity = 0;
    healthCalc();
    attackCalc();
    defenseCalc();
}

Character::Character(string characterName, Element elements, int rarities) {
    name = characterName;
    //Elemental type of character: {fire, water, earth, light, dark}
    elementalType = elements;
    //Rarity of character: {1-5 stars}
    rarity = rarities;
    //Health of the character is calculated by function. Determines how much damage it can withstand before being defeated
    healthCalc();
    //Attack of the character is calculated by function. Determines how much damage it can deal
    attackCalc();
    //Defense of the character is calculated by function. Determines how much damage will be reduced by opponent attacks
    defenseCalc();
}       
string Character::getName(){
  return name;
}
Element Character::getElement() {
    return elementalType;
}

int Character::getRarity() {
    return rarity;
}

int Character::getHealth() {
    return health;
}

int Character::getAttack() {
    return attack;
}

int Character::getDefense() {
    return defense;
}

void Character::healthCalc() {
    health = (100 + (rarity * 10));
}

void Character::attackCalc() {
    attack = (20 + (rarity * 5));
}

void Character::defenseCalc() {
    defense = (10 + (rarity * 2));
}

CharacterOutputter* Character::getCharacterOutput() {
    return characterOutput;
}
