#include "../header/CharacterInventoryOutputter.hpp"
#include "../header/CharacterOutputter.hpp"
#include "../header/Character.hpp"

#include <iostream>
#include <vector>

using namespace std;


void CharacterInventoryOutputter::displayCharacterInfo(Character* individual){
    individual->getCharacterOutput()->displayCharacterProfile(individual->getName(), individual->getElement(), individual->getRarity(), individual->getHealth(), individual->getAttack(), individual->getDefense());
}

void CharacterInventoryOutputter::displayCharacterList(vector<Character*> list){
    cout << "You have " << list.size() << " characters." << endl;
    for (int i = 0; i < list.size(); i++){
        cout << "Character " << i << ":" << endl;
        displayCharacterInfo(list.at(i));
        
    }
}